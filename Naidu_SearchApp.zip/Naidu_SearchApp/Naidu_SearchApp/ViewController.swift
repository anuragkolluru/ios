//
//  ViewController.swift
//  Naidu_SearchApp
//
//  Created by Naidu,Sujith Reddy on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        seacrhButtonOutlet.isEnabled = false
        nextButtonOutlet.isHidden = true
        previousButtonOutlet.isHidden = true
        resetButtonOutlet.isHidden = true
        resultImage.image = UIImage(named: "srch")
        
    }
    @IBOutlet weak var seacrhButtonOutlet: UIButton!
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    @IBOutlet weak var previousButtonOutlet: UIButton!
    @IBOutlet weak var resetButtonOutlet: UIButton!
    @IBAction func resetButtonClick(_ sender: Any) {
        nextButtonOutlet.isHidden = true
        previousButtonOutlet.isHidden = true
        resetButtonOutlet.isHidden = true
        topicInfoText.text = nil
        seacrhTextField.text = nil
        resultImage.image = UIImage(named: "srch")
        image = 0
        titleOutlet.text = nil
    }
    @IBOutlet weak var titleOutlet: UILabel!
    
    var comedian_title = ["Venu","posani","priyadarshi","brahmmi","ms"]
    var cricketer_title = ["Tim","langer","patty","marsh","starc"]
    var mansion_title = ["house1","house2","house3","house4","house5"]
    
    var arr_img = [["Venu","posani","priyadarshi","brahmmi","ms"],["tim payne","langer","patty","marsh","starc"],["house1","house2","house3","house4","house5"]]
    
    var arr_topics = ["comedian","cricketer","mansion"]
    
    var comedian_keywords = ["comedians","actors","comedian","actor","celebrities"]
    var cricketer_keywords = ["player","players","sports man","athelite"]
    var mansion_keywords = ["house","houses","mansion","villa","appartment","fort"]
    
    var comedian = ["Kunath Venu Madhav (died 25 September 2019) was an Indian actor, television presenter, mimicry artist and comedian known for his works predominantly in Telugu cinema. He was one of the finest comedians in the Telugu cinema, he starred in some 500 films in a variety of roles, starting his career as an impressionist; imitating celebrities, politicians, and local dialects.","Posani Krishna Murali (born 22 January 1958) is an Indian screenwriter, actor, director and producer who primarily works in Telugu cinema. He worked as a writer for over 150 Telugu films and directed a number of films. In 2009, he also contested in Andhra Pradesh state legislative assembly elections from Chilakaluripet constituency but lost the elections.","Priyadarshi Pulikonda (born 25 August 1989) is an Indian actor and comedian who works in Telugu films. He gained recognition for his role in Pelli Choopulu (2016). In addition to supporting roles, Priyadarshi played the lead in films such as Mallesham (2019), Mithai (2019), and Mail (2021). His performance in Mallesham (2019) appeared in the 100 Greatest Performances of the Decade by Film Companion.","Kanneganti Brahmanandam (born 1 February 1956), known mononymously as Brahmanandam, is an Indian actor, comedian, impersonator, voice actor and film director known for his works predominantly in Telugu cinema.[1] He currently holds the Guinness World Record for the most screen credits for a living actor, appearing in over 1000 films to date.[2][3][4] In 2009, he was honoured with the Padma Shri, the fourth-highest civilian award in India, for his contribution to Indian cinema.[5","]M. S. Narayana (16 April 1951–23 January 2015) was an Indian actor and comedian who worked in Telugu cinema. Narayana was a highly respected and popular comedian in Telugu films.[1] He died on 23 January 2015 due to organ failure in Hyderabad, India.,"]
    
    var cricketer = ["Timothy David Paine (born 8 December 1984) is an Australian cricketer and a former captain of the Australia national cricket team in Test cricket. A right-handed batsman and a wicket-keeper, he plays for the Tasmanian Tigers in Australian domestic cricket and was the captain of the Hobart Hurricanes before his selection for Australia in the 2017–18 Ashes series."," Justin Lee Langer AM (21 November 1970) is an Australian cricket coach and former cricketer. He is the former coach of the Australia men's national team, having been appointed to the role in May 2018 and leaving in February 2022. A left-handed batsman, Langer is best known for his partnership with Matthew Hayden as Australia's test opening batsmen during the early and mid-2000s, considered one of the most successful ever. Representing Western Australia domestically, Langer played English county cricket for Middlesex and also Somerset. He holds the record for the most runs scored at first-class level by an Australian."," Patrick James Cummins (born 8 May 1993) is an Australian international cricketer who is currently the captain of Australia in test cricket.[1][3] He is the vice-captain of the team in limited-overs cricket. He is a fast bowler and a capable lower-order right-handed batter,[4] and plays domestically for New South Wales. In the Indian Premier League, Cummins has represented Kolkata Knight Riders and Delhi Daredevils."," Shaun Edward Marsh (born 9 July 1983) is an Australian cricketer who plays for the Western Australia cricket team in Australian domestic cricket and has represented Australia in all three formats. Nicknamed SOS (Son of Swampy),[3] he is a left-handed top-order batsman. ","Mitchell Aaron Starc (born 30 January 1990) is an Australian international cricketer[3] who plays for the Australian national team and New South Wales in domestic cricket. He is a left-arm fast bowler and a capable lower order left-handed batsman. He was a prominent member of the victorious Australian squad that won the 2015 Cricket World Cup and was declared Player of the Tournament as a result of his consistent performances.He is regarded as one of the best bowlers in modern cricket[4] With 49 World Cup wickets, he is the joint 5th highest wicket taker in tournament's history."]
    
    var mansion = ["Buckingham Palace is not privately owned, being the property of Crown Estates, it is one of the homes of the Queen. With 775 rooms, there’s plenty of space for guests too!You can visit the 19 State Rooms during the Summer months, if you book well in advance. Tours also take in Buckingham Palace Garden, which is spread over 42 acres.There are 78 bathrooms in the palace, and an underground tunnel system connecting it with Clarence House and the Houses of Parliament.","  Antilia, India Standing 500 feet high, this 27 storey property is the home of Mukesh Ambani, Chairman of Reliance Industries, and his family. The gigantic house looks like a skyscraper. ","Biltmore Estate, USA One of the most impressive historic homes in America, the Biltmore Estate is thought to be the largest private home in the U.S. Set in 8,000 acres, the estate has 250 rooms.There are 43 bathrooms, 34 bedrooms, three kitchens and 65 fireplaces. Designed in the French Renaissance style, the mansion boasts several secret rooms.  ","Safra Mansion, Brazil The late Joseph Safra and his wife Vicky had the Safra Mansion built for them, although Joseph regretted having such a huge property. He once said, “if I could go back in time I wouldn’t have built such a big house”. ","Witanhurst, England This Grade II listed property is the second largest house in the UK, after Buckingham Palace. Designed in the Georgian Revival style, this Grade II listed property has been extensively refurbished."]
    
    var materials:Int!
    var image = 0

    
    @IBOutlet weak var seacrhTextField: UITextField!

    @IBAction func searchTextFieldAction(_ sender: Any) {
        if(!seacrhTextField.hasText){
            seacrhButtonOutlet.isEnabled = false
        }
        else{
            seacrhButtonOutlet.isEnabled = true
        }
    }
    
    
    @IBAction func searchButton(_ sender: Any) {
        nextButtonOutlet.isHidden = false

        previousButtonOutlet.isHidden = false
        if(image == 0){
        previousButtonOutlet.isEnabled = false
        nextButtonOutlet.isEnabled = true
        }
        else{
            previousButtonOutlet.isEnabled = true
        }
        resetButtonOutlet.isHidden = false
        resetButtonOutlet.isEnabled = true
        if(comedian_keywords.contains(seacrhTextField.text!)){
            materials = 0
            update(image: image, topicNumber: materials)
        }
        else if(cricketer_keywords.contains(seacrhTextField.text!)){
            materials = 1
            update(image: image, topicNumber: materials)
        }
        else if(mansion_keywords.contains(seacrhTextField.text!)){
            materials = 2
            update(image: image, topicNumber: materials)
        }
        else{
            resultImage.image = UIImage(named: "error")
            topicInfoText.text! = "Enter any other topic"
            nextButtonOutlet.isHidden = true
            previousButtonOutlet.isHidden = true
            resetButtonOutlet.isHidden = true
        }
        
    }
    
    func update(image: Int, topicNumber: Int){
        resultImage.image = UIImage(named: arr_img[materials][image])
        if(topicNumber == 0){
            topicInfoText.text = comedian[image]
            titleOutlet.text = comedian_title[image]
        }
        else if(topicNumber == 1){
            topicInfoText.text = cricketer[image]
            titleOutlet.text = cricketer_title[image]
        }
        else if(topicNumber == 2){
            topicInfoText.text = mansion[image]
            titleOutlet.text = mansion_title[image]
        }
    }
    
    @IBOutlet weak var resultImage: UIImageView!
    @IBAction func showNextImgBtn(_ sender: Any) {
        image += 1
        update(image: image, topicNumber: materials)
        if(materials == 0 && image == comedian.count-1){
            nextButtonOutlet.isEnabled = false
        }
        else if(materials == 1 && image == cricketer.count-1){
            nextButtonOutlet.isEnabled = false
        }
        else if(materials == 2 && image == mansion.count-1){
            nextButtonOutlet.isEnabled = false
        }
        previousButtonOutlet.isEnabled = true
        resetButtonOutlet.isHidden = false
        resetButtonOutlet.isEnabled = true
    }
    @IBAction func showPrevImgBtn(_ sender: Any) {
        image -= 1
        update(image: image, topicNumber: materials)
        if(materials == 0 && image == 0){
            previousButtonOutlet.isEnabled = false
        }
        else if(materials == 1 && image == 0){
            previousButtonOutlet.isEnabled = false
        }
        else if(materials == 2 && image == 0){
            previousButtonOutlet.isEnabled = false
        }
        nextButtonOutlet.isEnabled = true
    }
    @IBOutlet weak var topicInfoText: UITextView!
}

